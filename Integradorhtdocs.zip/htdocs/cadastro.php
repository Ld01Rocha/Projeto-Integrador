<?php
/**
 * Script corrigido para PharmaHealth - InfinityFree
 */

session_start();

// Configurações de resposta para o navegador
header('Content-Type: application/json; charset=utf-8');

// Inclui a conexão com o banco de dados
require_once 'conexao.php';

function enviarResposta($sucesso, $mensagem) {
    echo json_encode([
        'sucesso' => $sucesso,
        'mensagem' => $mensagem
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// Verifica se a requisição é POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    enviarResposta(false, 'Método não permitido');
}

// Recebe e limpa os dados do formulário
$nome  = htmlspecialchars(strip_tags(trim($_POST['name'] ?? '')), ENT_QUOTES, 'UTF-8');
$email = filter_var($_POST['email'] ?? '', FILTER_SANITIZE_EMAIL);
$senha = $_POST['password'] ?? '';
$confirmar_senha = $_POST['confirm_password'] ?? '';
$tipo_perfil = $_POST['role'] ?? '';

// Validação básica
if (empty($nome) || empty($email) || empty($senha) || empty($tipo_perfil)) {
    enviarResposta(false, 'Preencha todos os campos obrigatórios');
}

if ($senha !== $confirmar_senha) {
    enviarResposta(false, 'As senhas não coincidem');
}

if (strlen($senha) < 8) {
    enviarResposta(false, 'A senha deve ter no mínimo 8 caracteres');
}

try {
    // 1. Verifica se o e-mail já existe na tabela correta (tb_usuarios)
    $sql_verifica = "SELECT id FROM tb_usuarios WHERE email = ? LIMIT 1";
    $stmt_verifica = $conn->prepare($sql_verifica);
    $stmt_verifica->bind_param("s", $email);
    $stmt_verifica->execute();
    if ($stmt_verifica->get_result()->num_rows > 0) {
        enviarResposta(false, 'Este e-mail já está cadastrado');
    }
    $stmt_verifica->close();

    // 2. Hash da senha para segurança
    $senha_hash = password_hash($senha, PASSWORD_DEFAULT);

    // 3. Insere na tabela tb_usuarios (ajustado conforme seu banco)
    // Colunas: nome, email, senha, perfil
    $sql_insert = "INSERT INTO tb_usuarios (nome, email, senha, perfil) VALUES (?, ?, ?, ?)";
    $stmt_insert = $conn->prepare($sql_insert);
    
    if (!$stmt_insert) {
        throw new Exception($conn->error);
    }

    $stmt_insert->bind_param("ssss", $nome, $email, $senha_hash, $tipo_perfil);
    
    if ($stmt_insert->execute()) {
        enviarResposta(true, 'Cadastro realizado com sucesso! Agora você pode fazer login.');
    } else {
        throw new Exception($stmt_insert->error);
    }

} catch (Exception $e) {
    enviarResposta(false, 'Erro no servidor: ' . $e->getMessage());
} finally {
    if (isset($conn)) { $conn->close(); }
}
?>