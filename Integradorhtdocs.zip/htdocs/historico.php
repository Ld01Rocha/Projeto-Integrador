<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PharmaHealth - Histórico</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background-color: #f5f7fa;
            color: #333;
        }
        
        .container {
            display: flex;
            min-height: 100vh;
        }
        
        /* Sidebar */
        .sidebar {
            width: 250px;
            background: linear-gradient(135deg, #114b5f 0%, #1a936f 100%);
            color: white;
            padding: 20px 0;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
        }
        
        .logo {
            text-align: center;
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            margin-bottom: 20px;
        }
        
        .logo h1 {
            font-size: 24px;
            font-weight: 700;
        }
        
        .logo span {
            color: #88d498;
        }
        
        .user-info {
            text-align: center;
            padding: 15px;
            margin-bottom: 20px;
        }
        
        .user-avatar {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background-color: #88d498;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 15px;
            font-size: 30px;
        }
        
        .nav-menu {
            list-style: none;
        }
        
        .nav-menu li {
            padding: 12px 20px;
            margin: 5px 0;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
        }
        
        .nav-menu li i {
            margin-right: 10px;
            font-size: 18px;
        }
        
        .nav-menu li:hover, .nav-menu li.active {
            background-color: rgba(255, 255, 255, 0.1);
            border-left: 4px solid #88d498;
        }
        
        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 250px;
            padding: 20px;
        }
        
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            background-color: white;
            padding: 15px 20px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
        }
        
        .page-title {
            font-size: 24px;
            color: #114b5f;
        }
        
        .search-bar {
            display: flex;
            align-items: center;
            background: #f5f7fa;
            border-radius: 20px;
            padding: 5px 15px;
            width: 300px;
        }
        
        .search-bar input {
            border: none;
            background: transparent;
            padding: 8px;
            width: 100%;
            outline: none;
        }
        
        .user-actions {
            display: flex;
            align-items: center;
        }
        
        .notification-bell {
            position: relative;
            margin-right: 20px;
            cursor: pointer;
        }
        
        .notification-badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background-color: #e74c3c;
            color: white;
            border-radius: 50%;
            width: 18px;
            height: 18px;
            font-size: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        /* Dashboard Cards */
        .dashboard-cards {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
            display: flex;
            flex-direction: column;
        }
        
        .card-icon {
            width: 50px;
            height: 50px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 15px;
            font-size: 20px;
        }
        
        .card-title {
            font-size: 16px;
            color: #777;
            margin-bottom: 5px;
        }
        
        .card-value {
            font-size: 24px;
            font-weight: 700;
            color: #114b5f;
        }
        
        /* Content Box */
        .content-box {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
            margin-bottom: 30px;
        }
        
        .content-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 1px solid #eee;
        }
        
        .content-title {
            font-size: 18px;
            color: #114b5f;
        }
        
        .btn {
            background: linear-gradient(135deg, #114b5f 0%, #1a936f 100%);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            transition: all 0.3s ease;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
        }
        
        .btn i {
            margin-right: 8px;
        }
        
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(26, 147, 111, 0.4);
        }
        
        .btn-outline {
            background: transparent;
            border: 2px solid #1a936f;
            color: #1a936f;
        }
        
        /* Form */
        .form-row {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }
        
        .form-group {
            margin-bottom: 15px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #555;
        }
        
        .form-group input, .form-group select, .form-group textarea {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
            transition: border 0.3s ease;
        }
        
        .form-group input:focus, .form-group select:focus, .form-group textarea:focus {
            border-color: #1a936f;
            outline: none;
            box-shadow: 0 0 0 2px rgba(26, 147, 111, 0.2);
        }
        
        /* Table */
        .table-responsive {
            overflow-x: auto;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }
        
        th {
            background-color: #f8f9fa;
            color: #114b5f;
            font-weight: 600;
        }
        
        tr:hover {
            background-color: #f8f9fa;
        }
        
        .status {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
        }
        
        .status-active {
            background-color: #e6f7f0;
            color: #1a936f;
        }
        
        .status-inactive {
            background-color: #fef0f0;
            color: #e74c3c;
        }
        
        .status-pending {
            background-color: #fef7e6;
            color: #f39c12;
        }
        
        .status-taken {
            background-color: #e6f7f0;
            color: #1a936f;
        }
        
        .status-missed {
            background-color: #fef0f0;
            color: #e74c3c;
        }
        
        .status-delayed {
            background-color: #fef7e6;
            color: #f39c12;
        }
        
        .action-btn {
            background: none;
            border: none;
            cursor: pointer;
            margin-right: 10px;
            color: #114b5f;
            font-size: 16px;
        }
        
        /* Filters */
        .filters {
            display: flex;
            gap: 15px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }
        
        .filter-group {
            display: flex;
            align-items: center;
        }
        
        .filter-group label {
            margin-right: 8px;
            font-weight: 500;
            color: #555;
        }
        
        .filter-group select, .filter-group input {
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        
        /* Tabs */
        .tabs {
            display: flex;
            margin-bottom: 20px;
            border-bottom: 1px solid #ddd;
        }
        
        .tab {
            padding: 10px 20px;
            cursor: pointer;
            text-align: center;
            transition: all 0.3s ease;
            color: #777;
            border-bottom: 3px solid transparent;
        }
        
        .tab.active {
            border-bottom: 3px solid #1a936f;
            color: #114b5f;
            font-weight: bold;
        }
        
        /* Timeline */
        .timeline {
            position: relative;
            padding-left: 30px;
        }
        
        .timeline::before {
            content: '';
            position: absolute;
            left: 10px;
            top: 0;
            bottom: 0;
            width: 2px;
            background-color: #ddd;
        }
        
        .timeline-item {
            position: relative;
            margin-bottom: 20px;
        }
        
        .timeline-dot {
            position: absolute;
            left: -30px;
            top: 5px;
            width: 20px;
            height: 20px;
            border-radius: 50%;
            background-color: #1a936f;
        }
        
        .timeline-content {
            background: white;
            padding: 15px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
        }
        
        .timeline-date {
            font-size: 12px;
            color: #777;
            margin-bottom: 5px;
        }
        
        .timeline-title {
            font-weight: 600;
            margin-bottom: 5px;
            color: #114b5f;
        }
        
        .timeline-desc {
            font-size: 14px;
            color: #555;
        }
        
        /* Dependent Selector */
        .dependent-selector {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
            padding: 10px;
            background-color: #f8f9fa;
            border-radius: 8px;
        }
        
        .dependent-selector label {
            margin-right: 10px;
            font-weight: 500;
        }
        
        .dependent-selector select {
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            background-color: white;
        }
        
        /* Responsive */
        @media (max-width: 992px) {
            .sidebar {
                width: 70px;
                overflow: visible;
            }
            
            .sidebar .logo h1, .sidebar .user-info, .sidebar .nav-menu li span {
                display: none;
            }
            
            .sidebar .nav-menu {
                text-align: center;
            }
            
            .sidebar .nav-menu li i {
                margin-right: 0;
                font-size: 20px;
            }
            
            .main-content {
                margin-left: 70px;
            }
        }
        
        @media (max-width: 768px) {
            .dashboard-cards {
                grid-template-columns: 1fr;
            }
            
            .header {
                flex-direction: column;
                gap: 15px;
            }
            
            .search-bar {
                width: 100%;
            }
            
            .form-row {
                grid-template-columns: 1fr;
            }
            
            .filters {
                flex-direction: column;
                align-items: flex-start;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="logo">
                <h1>Pharma<span>Health</span></h1>
            </div>
            
            <div class="user-info">
                <div class="user-avatar">
                    <i class="fas fa-user"></i>
                </div>
                <h3>Carlos Silva</h3>
                <p>Paciente</p>
            </div>
            
          <ul class="nav-menu">
<li class="active"><a href="PaginaInicialCuidador.php"> <i class="fas fa-home"></i> <span>Dashboard</span> </a></li>
<li><a href="medicamento.php"> <i class="fas fa-pills"></i> <span>Medicamentos</span> </a></li>
<li><a href="dependentes.php"> <i class="fas fa-users"></i> <span>Dependentes</span> </a></li>
<li><a href="alerta.php"> <i class="fas fa-bell"></i> <span>Alertas</span> </a></li>
<li><a href="historico.php"> <i class="fas fa-history"></i> <span>Histórico</span> </a></li>
<li><a href="configuracoes.php"> <i class="fas fa-cog"></i> <span>Configurações</span> </a></li>
<li><a href="index.php"> <i class="fas fa-sign-out-alt"></i> <span>Sair</span> </a></li>
</ul>
        </div>
        
        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h2 class="page-title">Histórico</h2>
                
                <div class="search-bar">
                    <i class="fas fa-search"></i>
                    <input type="text" placeholder="Pesquisar no histórico...">
                </div>
                
                <div class="user-actions">
                    <div class="notification-bell">
                        <i class="fas fa-bell"></i>
                        <span class="notification-badge">3</span>
                    </div>
                    <div class="user-name">Carlos Silva</div>
                </div>
            </div>
            
            <!-- Dashboard Cards -->
            <div class="dashboard-cards">
                <div class="card">
                    <div class="card-icon" style="background-color: #e6f7f0; color: #1a936f;">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <div class="card-title">Medicamentos Tomados</div>
                    <div class="card-value">128</div>
                </div>
                
                <div class="card">
                    <div class="card-icon" style="background-color: #fef0f0; color: #e74c3c;">
                        <i class="fas fa-times-circle"></i>
                    </div>
                    <div class="card-title">Medicamentos Omitidos</div>
                    <div class="card-value">12</div>
                </div>
                
                <div class="card">
                    <div class="card-icon" style="background-color: #fff7e6; color: #f39c12;">
                        <i class="fas fa-clock"></i>
                    </div>
                    <div class="card-title">Medicamentos Atrasados</div>
                    <div class="card-value">8</div>
                </div>
                
                <div class="card">
                    <div class="card-icon" style="background-color: #e6f3ff; color: #3498db;">
                        <i class="fas fa-bell"></i>
                    </div>
                    <div class="card-title">Alertas Registrados</div>
                    <div class="card-value">23</div>
                </div>
            </div>
            
            <!-- Filtros -->
            <div class="content-box">
                <div class="content-header">
                    <h3 class="content-title">Filtrar Histórico</h3>
                </div>
                
                <div class="filters">
                    <div class="filter-group">
                        <label for="date-from">De:</label>
                        <input type="date" id="date-from">
                    </div>
                    
                    <div class="filter-group">
                        <label for="date-to">Até:</label>
                        <input type="date" id="date-to">
                    </div>
                    
                    <div class="filter-group">
                        <label for="filter-patient">Paciente:</label>
                        <select id="filter-patient">
                            <option value="all">Todos</option>
                            <option value="self">Carlos Silva</option>
                            <option value="dependent-1">Maria Silva</option>
                            <option value="dependent-2">José Silva</option>
                        </select>
                    </div>
                    
                    <div class="filter-group">
                        <label for="filter-type">Tipo:</label>
                        <select id="filter-type">
                            <option value="all">Todos</option>
                            <option value="taken">Tomados</option>
                            <option value="missed">Omitidos</option>
                            <option value="delayed">Atrasados</option>
                            <option value="alert">Alertas</option>
                        </select>
                    </div>
                    
                    <button class="btn" onclick="applyFilters()">
                        <i class="fas fa-filter"></i> Aplicar Filtros
                    </button>
                    
                    <button class="btn btn-outline" onclick="clearFilters()">
                        <i class="fas fa-times"></i> Limpar
                    </button>
                </div>
            </div>
            
            <!-- Tabs -->
            <div class="tabs">
                <div class="tab active" onclick="showTab('timeline')">Linha do Tempo</div>
                <div class="tab" onclick="showTab('table')">Visualização em Tabela</div>
            </div>
            
            <!-- Timeline View -->
            <div id="timeline-view" class="content-box">
                <div class="content-header">
                    <h3 class="content-title">Linha do Tempo</h3>
                </div>
                
                <div class="timeline">
                    <div class="timeline-item">
                        <div class="timeline-dot"></div>
                        <div class="timeline-content">
                            <div class="timeline-date">Hoje, 08:15</div>
                            <div class="timeline-title">Paracetamol - Tomado</div>
                            <div class="timeline-desc">500mg • 1 comprimido • Confirmado com 15min de atraso</div>
                        </div>
                    </div>
                    
                    <div class="timeline-item">
                        <div class="timeline-dot"></div>
                        <div class="timeline-content">
                            <div class="timeline-date">Hoje, 08:00</div>
                            <div class="timeline-title">Alerta - Medicamento Crítico</div>
                            <div class="timeline-desc">Insulina precisa ser administrada em até 1 hora</div>
                        </div>
                    </div>
                    
                    <div class="timeline-item">
                        <div class="timeline-dot"></div>
                        <div class="timeline-content">
                            <div class="timeline-date">Ontem, 22:05</div>
                            <div class="timeline-title">Sinvastatina (José Silva) - Omitido</div>
                            <div class="timeline-desc">20mg • Não foi administrado • Paciente recusou</div>
                        </div>
                    </div>
                    
                    <div class="timeline-item">
                        <div class="timeline-dot"></div>
                        <div class="timeline-content">
                            <div class="timeline-date">Ontem, 14:00</div>
                            <div class="timeline-title">Amoxicilina (Maria Silva) - Tomado</div>
                            <div class="timeline-desc">250mg • 1 comprimido • Confirmado no horário</div>
                        </div>
                    </div>
                    
                    <div class="timeline-item">
                        <div class="timeline-dot"></div>
                        <div class="timeline-content">
                            <div class="timeline-date">Ontem, 12:00</div>
                            <div class="timeline-title">Insulina - Tomado</div>
                            <div class="timeline-desc">10 unidades • Aplicação subcutânea • Confirmado no horário</div>
                        </div>
                    </div>
                    
                    <div class="timeline-item">
                        <div class="timeline-dot"></div>
                        <div class="timeline-content">
                            <div class="timeline-date">Ontem, 10:30</div>
                            <div class="timeline-title">Losartana - Tomado</div>
                            <div class="timeline-desc">50mg • 1 comprimido • Confirmado no horário</div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Table View -->
            <div id="table-view" class="content-box" style="display: none;">
                <div class="content-header">
                    <h3 class="content-title">Histórico em Tabela</h3>
                </div>
                
                <div class="table-responsive">
                    <table>
                        <thead>
                            <tr>
                                <th>Data/Hora</th>
                                <th>Paciente</th>
                                <th>Medicamento</th>
                                <th>Dosagem</th>
                                <th>Tipo</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>10/06/2023 08:15</td>
                                <td>Carlos Silva</td>
                                <td>Paracetamol</td>
                                <td>500mg</td>
                                <td>Medicação</td>
                                <td><span class="status status-delayed">Atrasado</span></td>
                            </tr>
                            <tr>
                                <td>10/06/2023 08:00</td>
                                <td>Carlos Silva</td>
                                <td>Insulina</td>
                                <td>10 unidades</td>
                                <td>Alerta</td>
                                <td><span class="status status-missed">Crítico</span></td>
                            </tr>
                            <tr>
                                <td>09/06/2023 22:05</td>
                                <td>José Silva</td>
                                <td>Sinvastatina</td>
                                <td>20mg</td>
                                <td>Medicação</td>
                                <td><span class="status status-missed">Omitido</span></td>
                            </tr>
                            <tr>
                                <td>09/06/2023 14:00</td>
                                <td>Maria Silva</td>
                                <td>Amoxicilina</td>
                                <td>250mg</td>
                                <td>Medicação</td>
                                <td><span class="status status-taken">Tomado</span></td>
                            </tr>
                            <tr>
                                <td>09/06/2023 12:00</td>
                                <td>Carlos Silva</td>
                                <td>Insulina</td>
                                <td>10 unidades</td>
                                <td>Medicação</td>
                                <td><span class="status status-taken">Tomado</span></td>
                            </tr>
                            <tr>
                                <td>09/06/2023 10:30</td>
                                <td>Carlos Silva</td>
                                <td>Losartana</td>
                                <td>50mg</td>
                                <td>Medicação</td>
                                <td><span class="status status-taken">Tomado</span></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Função para alternar entre as abas
        function showTab(tabName) {
            const tabs = document.querySelectorAll('.tab');
            tabs.forEach(tab => tab.classList.remove('active'));
            
            document.getElementById('timeline-view').style.display = 'none';
            document.getElementById('table-view').style.display = 'none';
            
            if (tabName === 'timeline') {
                document.querySelector('.tab:nth-child(1)').classList.add('active');
                document.getElementById('timeline-view').style.display = 'block';
            } else {
                document.querySelector('.tab:nth-child(2)').classList.add('active');
                document.getElementById('table-view').style.display = 'block';
            }
        }
        
        // Função para aplicar filtros
        function applyFilters() {
            const dateFrom = document.getElementById('date-from').value;
            const dateTo = document.getElementById('date-to').value;
            const patient = document.getElementById('filter-patient').value;
            const type = document.getElementById('filter-type').value;
            
            // Simulação de aplicação de filtros
            alert(`Filtros aplicados:\nDe: ${dateFrom || 'Nenhum'}\nAté: ${dateTo || 'Nenhum'}\nPaciente: ${patient}\nTipo: ${type}`);
            
            // Aqui você implementaria a lógica real de filtragem
        }
        
        // Função para limpar filtros
        function clearFilters() {
            document.getElementById('date-from').value = '';
            document.getElementById('date-to').value = '';
            document.getElementById('filter-patient').value = 'all';
            document.getElementById('filter-type').value = 'all';
            
            alert('Filtros limpos!');
            
            // Aqui você recarregaria os dados sem filtros
        }
        
        // Inicializar a página
        document.addEventListener('DOMContentLoaded', function() {
            // Definir a data atual como padrão para o filtro "até"
            const today = new Date().toISOString().split('T')[0];
            document.getElementById('date-to').value = today;
            
            // Definir 7 dias atrás como padrão para o filtro "de"
            const sevenDaysAgo = new Date();
            sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
            document.getElementById('date-from').value = sevenDaysAgo.toISOString().split('T')[0];
        });
    </script>
</body>
</html>