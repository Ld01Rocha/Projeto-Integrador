<?php
// 1. Inicia a sessão e conecta ao banco
session_start();
include('conexao.php');

// 2. Proteção: Verifica se o usuário está logado
if (!isset($_SESSION['usuario_id'])) {
    header("Location: index.php");
    exit();
}

$id_logado = $_SESSION['usuario_id'];
$nome_logado = $_SESSION['usuario_nome'] ?? 'Cuidador';

// 3. BUSCA DE DADOS REAIS
// Conta medicamentos na tb_medicamentos
$sql_meds = "SELECT COUNT(*) as total FROM tb_medicamentos WHERE id_usuario = '$id_logado'";
$res_meds = mysqli_query($conn, $sql_meds);
$total_meds = mysqli_fetch_assoc($res_meds)['total'] ?? 0;

// Conta dependentes na tb_cuidadores_pacientes
$sql_dep = "SELECT COUNT(*) as total FROM tb_cuidadores_pacientes WHERE id_cuidador = '$id_logado'";
$res_dep = mysqli_query($conn, $sql_dep);
$total_dep = mysqli_fetch_assoc($res_dep)['total'] ?? 0;
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PharmaHealth - Dashboard do Cuidador</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* CSS unificado baseado no estilo do Paciente */
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        body { background-color: #f5f7fa; color: #333; }
        .container { display: flex; min-height: 100vh; }
        
        /* Sidebar */
        .sidebar { width: 250px; background: linear-gradient(135deg, #114b5f 0%, #1a936f 100%); color: white; padding: 20px 0; position: fixed; height: 100vh; overflow-y: auto; }
        .logo { text-align: center; padding: 0 20px 20px; border-bottom: 1px solid rgba(255, 255, 255, 0.1); margin-bottom: 20px; }
        .logo h1 { font-size: 24px; font-weight: 700; }
        .logo span { color: #88d498; }
        .user-info { text-align: center; padding: 15px; margin-bottom: 20px; }
        .user-avatar { width: 80px; height: 80px; border-radius: 50%; background-color: #88d498; display: flex; align-items: center; justify-content: center; margin: 0 auto 15px; font-size: 30px; color: #114b5f; }
        
        .nav-menu { list-style: none; }
        .nav-menu li { padding: 12px 20px; margin: 5px 0; transition: all 0.3s; display: flex; align-items: center; }
        .nav-menu a { color: white; text-decoration: none; display: flex; align-items: center; width: 100%; }
        .nav-menu li i { margin-right: 10px; font-size: 18px; }
        .nav-menu li:hover, .nav-menu li.active { background-color: rgba(255, 255, 255, 0.1); border-left: 4px solid #88d498; }

        /* Main Content */
        .main-content { flex: 1; margin-left: 250px; padding: 20px; }
        .header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px; background-color: white; padding: 15px 20px; border-radius: 10px; box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05); }
        .page-title { font-size: 24px; color: #114b5f; }

        /* Dashboard Cards */
        .dashboard-cards { display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 20px; margin-bottom: 30px; }
        .card { background: white; border-radius: 10px; padding: 20px; box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05); }
        .card-icon { width: 50px; height: 50px; border-radius: 10px; display: flex; align-items: center; justify-content: center; margin-bottom: 15px; font-size: 20px; }
        .card-title { font-size: 16px; color: #777; margin-bottom: 5px; }
        .card-value { font-size: 24px; font-weight: 700; color: #114b5f; }

        .content-box { background: white; border-radius: 10px; padding: 20px; box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05); }
        .content-title { font-size: 18px; color: #114b5f; margin-bottom: 15px; border-bottom: 1px solid #eee; padding-bottom: 10px; }

        @media (max-width: 992px) {
            .sidebar { width: 70px; }
            .sidebar .logo, .sidebar .user-info h3, .sidebar .user-info p, .nav-menu span { display: none; }
            .main-content { margin-left: 70px; }
        }
    </style>
</head>
<body>

    <div class="container">
        <div class="sidebar">
            <div class="logo">
                <h1>Pharma<span>Health</span></h1>
            </div>
            <div class="user-info">
                <div class="user-avatar"><i class="fas fa-user-md"></i></div>
                <h3><?php echo $nome_logado; ?></h3>
                <p>Cuidador</p>
            </div>
            <ul class="nav-menu">
                <li class="active"><a href="PaginaInicialCuidador.php"><i class="fas fa-home"></i> <span>Dashboard</span></a></li>
                <li><a href="medicamento.php"><i class="fas fa-pills"></i> <span>Medicamentos</span></a></li>
                <li><a href="dependentes.php"><i class="fas fa-users"></i> <span>Pacientes</span></a></li>
                <li><a href="historico.php"><i class="fas fa-history"></i> <span>Relatórios</span></a></li>
                <li><a href="index.php"><i class="fas fa-sign-out-alt"></i> <span>Sair</span></a></li>
            </ul>
        </div>

        <div class="main-content">
            <div class="header">
                <h2 class="page-title">Dashboard do Cuidador</h2>
                <div class="user-actions">
                    <span>Olá, <strong><?php echo $nome_logado; ?></strong></span>
                </div>
            </div>

            <div class="dashboard-cards">
                <div class="card">
                    <div class="card-icon" style="background-color: #e6f7f0; color: #1a936f;">
                        <i class="fas fa-pills"></i>
                    </div>
                    <div class="card-title">Medicamentos Ativos</div>
                    <div class="card-value"><?php echo $total_meds; ?></div>
                </div>
                
                <div class="card">
                    <div class="card-icon" style="background-color: #ebf5ff; color: #2980b9;">
                        <i class="fas fa-user-injured"></i>
                    </div>
                    <div class="card-title">Pacientes sob Cuidado</div>
                    <div class="card-value"><?php echo $total_dep; ?></div>
                </div>

                <div class="card">
                    <div class="card-icon" style="background-color: #fef0f0; color: #e74c3c;">
                        <i class="fas fa-bell"></i>
                    </div>
                    <div class="card-title">Alertas Hoje</div>
                    <div class="card-value">0</div>
                </div>
            </div>

            <div class="content-box">
                <h3 class="content-title">Monitoramento de Próximas Doses</h3>
                <p style="color: #666;">Acesse a aba de <strong>Medicamentos</strong> para confirmar as ministrações dos seus pacientes.</p>
                </div>
        </div>
    </div>

</body>
</html>