<?php
include("conexao.php"); 
session_start();

// --- LÓGICA DE LOGIN COM PRÉ-DEFINIÇÕES E BANCO ---
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['email']) && !isset($_POST['name'])) {
    $email = $_POST['email'];
    $senha = $_POST['password'];
    $tipo = $_POST['role'];

    // Verificação de Usuários Pré-definidos
    if ($email == 'lucasdavidrocha13@gmail.com' && $senha == '@Chiconha00' && $tipo == 'paciente') {
        $_SESSION['usuario'] = $email;
        header("Location: PaginaInicialPaciente.php");
        exit();
    } 
    elseif ($email == 'lucas.drocha@sempreceub.com' && $senha == '@Chiconha00' && $tipo == 'cuidador') {
        $_SESSION['usuario'] = $email;
        header("Location: PaginaInicialCuidador.php");
        exit();
    }

    // Consulta no Banco de Dados
    $sql = "SELECT * FROM tb_usuarios WHERE email = '$email' AND senha = '$senha' AND tipo = '$tipo'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $_SESSION['usuario'] = $email;
        if ($tipo == 'cuidador') {
            header("Location: PaginaInicialCuidador.php");
        } else {
            header("Location: PaginaInicialPaciente.php");
        }
        exit();
    } else {
        echo "<script>alert('E-mail, senha ou perfil incorretos!');</script>";
    }
}

// --- LÓGICA DE CADASTRO ---
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['name'])) {
    $nome = $_POST['name'];
    $email = $_POST['email'];
    $senha = $_POST['password'];
    $tipo = $_POST['role'];

    $sql = "INSERT INTO tb_usuarios (nome, email, senha, tipo) VALUES ('$nome', '$email', '$senha', '$tipo')";
    
    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Cadastro realizado com sucesso!'); window.location.href='index.php';</script>";
    } else {
        echo "Erro ao cadastrar: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PharmaHealth - Login e Cadastro</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        'ph-primary': '#10b981',
                        'ph-dark': '#0f766e',
                        'ph-accent': '#047857',
                    },
                    fontFamily: { sans: ['Inter', 'sans-serif'] },
                }
            }
        }
    </script>
    <style>
        body { background: linear-gradient(135deg, #0f766e 0%, #11a282 100%); min-height: 100vh; display: flex; align-items: center; justify-content: center; font-family: 'Inter', sans-serif; padding: 1rem; }
        .form-content { display: none; }
        .form-content.active { display: block; }
        .tab-button { transition: all 0.2s; cursor: pointer; padding-bottom: 0.5rem; border-bottom: 3px solid transparent; font-weight: 500; }
        .tab-button.active { color: #10b981; border-bottom-color: #10b981; font-weight: 600; }
        .btn-primary { background-color: #10b981; transition: background-color 0.2s; }
        .btn-primary:hover { background-color: #047857; }
    </style>
</head>
<body>

    <div id="app-card" class="bg-white shadow-2xl rounded-xl max-w-4xl w-full flex flex-col md:flex-row overflow-hidden">
        
        <div class="md:w-1/2 p-8 text-white bg-ph-accent bg-opacity-90 flex flex-col justify-center space-y-6">
            <h1 class="text-3xl font-bold tracking-tight">PharmaHealth</h1>
            <h2 class="text-2xl font-semibold mt-6">Cuide de quem você ama</h2>
            <ul class="space-y-3 pt-4">
                <li class="flex items-start text-lg"><span class="mr-3 text-2xl">🔔</span> Lembretes inteligentes</li>
                <li class="flex items-start text-lg"><span class="mr-3 text-2xl">📈</span> Acompanhamento em tempo real</li>
                <li class="flex items-start text-lg"><span class="mr-3 text-2xl">🧑‍🤝‍🧑</span> Perfis para pacientes e cuidadores</li>
            </ul>
        </div>

        <div class="md:w-1/2 p-8 md:p-12 space-y-8">
            <div class="flex border-b border-gray-200">
                <button id="tab-login" class="tab-button active mr-6" onclick="showForm('login')">Login</button>
                <button id="tab-cadastro" class="tab-button" onclick="showForm('cadastro')">Cadastro</button>
            </div>

            <form id="form-login" class="form-content active space-y-6" action="index.php" method="POST">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">E-mail</label>
                    <input type="email" id="login-email" name="email" value="lucasdavidrocha13@gmail.com" required class="w-full px-4 py-2 border rounded-lg focus:ring-ph-primary focus:border-ph-primary">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Senha</label>
                    <input type="password" name="password" value="@Chiconha00" required class="w-full px-4 py-2 border rounded-lg focus:ring-ph-primary focus:border-ph-primary">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Entrar como:</label>
                    <select name="role" required class="w-full px-4 py-2 border rounded-lg">
                        <option value="paciente" selected>Paciente</option>
                        <option value="cuidador">Cuidador</option>
                    </select>
                </div>
                
                <button type="submit" class="btn-primary w-full text-white font-semibold py-2.5 rounded-lg shadow-md">Entrar</button>
                
                <div class="flex flex-col items-center space-y-2 text-sm pt-2">
                    <button type="button" class="text-ph-primary font-medium hover:underline" onclick="showForm('cadastro')">
                        Criar uma conta
                    </button>
                    <button type="button" onclick="recuperarSenhaUsuario()" class="text-gray-500 hover:text-ph-primary transition-colors">
                        Esqueceu a senha?
                    </button>
                </div>
            </form>

            <form id="form-cadastro" class="form-content space-y-6" action="index.php" method="POST">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Nome Completo</label>
                    <input type="text" name="name" required class="w-full px-4 py-2 border rounded-lg">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">E-mail</label>
                    <input type="email" name="email" required class="w-full px-4 py-2 border rounded-lg">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Senha</label>
                    <input type="password" name="password" minlength="8" required class="w-full px-4 py-2 border rounded-lg">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Você será:</label>
                    <select name="role" required class="w-full px-4 py-2 border rounded-lg">
                        <option value="paciente">Paciente</option>
                        <option value="cuidador">Cuidador</option>
                    </select>
                </div>
                <button type="submit" class="btn-primary w-full text-white font-semibold py-2.5 rounded-lg shadow-md">Criar Minha Conta</button>
                <div class="text-center text-sm pt-2">
                    <button type="button" class="text-ph-primary font-medium hover:underline" onclick="showForm('login')">Já tenho conta (Login)</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function showForm(formType) {
            document.querySelectorAll('.tab-button').forEach(btn => btn.classList.remove('active'));
            document.querySelectorAll('.form-content').forEach(form => form.classList.remove('active'));
            document.getElementById(`tab-${formType}`).classList.add('active');
            document.getElementById(`form-${formType}`).classList.add('active');
        }

        function recuperarSenhaUsuario() {
            const emailDigitado = document.getElementById('login-email').value;
            const seuEmailAdmin = "lucasdavidrocha13@gmail.com";
            
            if (emailDigitado === seuEmailAdmin) {
                window.location.href = 'recuperar_senha.php';
            } else {
                alert('A recuperação de senha automática está habilitada apenas para o administrador.');
            }
        }
    </script>
</body>
</html>