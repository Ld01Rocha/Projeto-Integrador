<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
include("conexao.php");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $emailDestino = $_POST['email'];

    // 1. Verifica se o e-mail existe no banco
    $sql = "SELECT * FROM tb_usuarios WHERE email = '$emailDestino'";
    $res = $conn->query($sql);

    if ($res->num_rows > 0) {
        $mail = new PHPMailer(true);
        try {
            // Configurações do Servidor
            $mail->isSMTP();
            $mail->Host       = 'smtp.gmail.com';
            $mail->SMTPAuth   = true;
            $mail->Username   = 'lucasdavidrocha13@gmail.com'; // Seu e-mail
            $mail->Password   = 'SUA_SENHA_DE_16_DIGITOS';    // A senha que você gerou no Google
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port       = 587;

            // Destinatário
            $mail->setFrom('lucasdavidrocha13@gmail.com', 'PharmaHealth');
            $mail->addAddress($emailDestino);

            // Conteúdo do e-mail
            $mail->isHTML(true);
            $mail->Subject = 'Recuperar Senha - PharmaHealth';
            $mail->Body    = "Para redefinir sua senha, clique no link: <br><br>
                              <a href='http://pharmahealth.42web.io/nova_senha.php?email=$emailDestino'>Redefinir Minha Senha</a>";

            $mail->send();
            echo "<script>alert('Link enviado com sucesso para seu e-mail!');</script>";
        } catch (Exception $e) {
            echo "<script>alert('Erro ao enviar: {$mail->ErrorInfo}');</script>";
        }
    } else {
        echo "<script>alert('E-mail não encontrado no sistema.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Recuperar Senha</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-[#0f766e] flex items-center justify-center min-h-screen">
    <form method="POST" class="bg-white p-8 rounded-xl shadow-lg w-96 text-center">
        <h2 class="text-2xl font-bold mb-4 text-[#0f766e]">Esqueci a Senha</h2>
        <input type="email" name="email" placeholder="Digite seu e-mail" required class="w-full p-2 border rounded mb-4">
        <button type="submit" class="bg-[#10b981] text-white w-full py-2 rounded font-bold hover:bg-[#059669]">Enviar Link</button>
        <a href="index.php" class="block mt-4 text-sm text-gray-500">Voltar ao login</a>
    </form>
</body>
</html>